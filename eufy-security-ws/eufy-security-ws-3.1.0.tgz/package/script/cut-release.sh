# ==========================================
# CUT RELEASE
# ==========================================

# Check if all arguments are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <version> <client_version>"
    echo "Example: $0 '2.0.0' '3.0.0'"
    exit 1
fi

VERSION=$1
CLIENT_VERSION=$2

## Checkout develop
git checkout develop

## Pull the latest
git pull origin develop

## Make branch for the release
git checkout -b "release/$VERSION" || exit 1

# Update file
jq --arg v "$VERSION" '.version = $v' package.json > package.json.tmp && mv package.json.tmp package.json
sed -i 's|<small>.*</small>|<small>'$VERSION'</small>|' docs/_coverpage.md
jq --arg v "$CLIENT_VERSION" '.dependencies["eufy-security-client"] = $v' package.json > package.json.tmp && mv package.json.tmp package.json

# Make the package-lock update
npm i

# Add file to the branch and commit
git add package.json
git add package-lock.json
git add docs/_coverpage.md
git commit -m "Add new version"
#
## Push
#git push --set-upstream origin "release/$VERSION"